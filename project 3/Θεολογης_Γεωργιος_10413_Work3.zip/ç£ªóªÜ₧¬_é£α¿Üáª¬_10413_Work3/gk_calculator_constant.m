function [gk] = gk_calculator_constant(g,junk1,junk2)
gk=g;
end